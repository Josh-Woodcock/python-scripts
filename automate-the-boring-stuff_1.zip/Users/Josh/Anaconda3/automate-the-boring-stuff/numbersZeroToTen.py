print('Imma gonna print sum numbas using dah FOR LOOP')

for i in range(1,11):
    print (i)


print('Imma gonna print sum numbas using dah WHILE LOOP')

i = 0
while i <= 9:
    i = i + 1
    print(i)



