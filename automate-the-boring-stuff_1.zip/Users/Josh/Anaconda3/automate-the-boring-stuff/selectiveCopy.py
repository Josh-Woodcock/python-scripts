#! python3
# selectiveCopy.py - Copies an entire folder and its contents into
# a ZIP file whose filename increments.

import zipfile, os, shutil

def selectiveCopy(folder):

    source = os.path.abspath(folder)    # make sure folder is absolute
    
    newFoldername = os.path.basename(folder) + '_txtFiles' 

    # Create the Directory

    print('Creating %s...' % (newFoldername))
    destination = os.makedirs(newFoldername)

    for foldername, subfolders, filenames in os.walk(source):
        for filename in filenames:
            if filename.endswith('.txt'):
                # shutil.copy(filename,destination)
                print('Adding %s...' % (filename))

    print('Done.')


selectiveCopy('C:\\delicious')
